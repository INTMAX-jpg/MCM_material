import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 1) 读入数据
df = pd.read_excel("final_result.xlsx")
# 数据列: [NOC, All_Medals_Pred, Gold_Pred]

# 2) 整数化: round()
df["All_Medals_int"] = df["All_Medals_Pred"].round().astype(int)
df["Gold_int"]       = df["Gold_Pred"].round().astype(int)

# 3) 先按 "Gold_int" 降序，再按 "All_Medals_int" 降序
df = df.sort_values(["Gold_int", "All_Medals_int"], ascending=[False, False])

# 4) 取前12
df_top12 = df.head(12)

# 5) 计算 "其他奖牌数" = All_Medals_int - Gold_int
#    避免出现负值(若因四舍五入导致Gold>All),可做clip
df_top12["Other_int"] = np.maximum(df_top12["All_Medals_int"] - df_top12["Gold_int"], 0)

# 6) 堆叠柱状图 (Stacked Bar)
x_idx = np.arange(len(df_top12))  # 0..11
gold_vals  = df_top12["Gold_int"].values
other_vals = df_top12["Other_int"].values

plt.figure(figsize=(10,6))

bar_gold = plt.bar(
    x_idx,
    gold_vals,
    color="gold",
    label="Gold"
)
bar_other = plt.bar(
    x_idx,
    other_vals,
    bottom=gold_vals,
    color="gray",
    label="Other Medals"
)

# 7) X轴替换成 NOC
plt.xticks(x_idx, df_top12["NOC"], rotation=45, ha='right')

# 8) 给每个区段加数值标签(整型)
#   - bar_gold 对应金牌数, bar_other 对应其他奖牌
#   - 最后可再加"总数" 或仅显示这两个？
#   - 这里演示都显示: "金牌"写在金牌条中央, "其他"写在其他条中央
plt.bar_label(bar_gold, padding=2)   # 显示金牌数
plt.bar_label(bar_other, padding=2)  # 显示其他牌数

# 如果你还想在最顶端显示总数( All_Medals_int ), 可以额外写:
#   for i in range(len(df_top12)):
#       total_val = df_top12["All_Medals_int"].iloc[i]
#       plt.text(x_idx[i], gold_vals[i]+other_vals[i]+0.5,
#                str(total_val), ha="center", va="bottom")

plt.ylabel("Number of Medals")
plt.title("Los Angeles 2028 Predicted Medal Table")
plt.legend()
plt.tight_layout()
plt.show()
