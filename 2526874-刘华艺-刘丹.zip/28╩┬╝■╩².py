import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import cross_val_score

# 原始数据（事件数），对应的年份是2000, 2004, 2008, 2012, 2016, 2020, 2024
years = np.array([2000, 2004, 2008, 2012, 2016, 2020, 2024])
events = np.array([300, 301, 302, 302, 306, 339, 329])

# 将年份差异作为时间步长，得到离散时间序列（2000年到2024年，每4年为一步）
time_series = np.array([1, 2, 3, 4, 5, 6, 7])  # 这里只是时间点，不是真实年份


# 多项式回归的模型训练和预测
def polynomial_regression(degree):
    # 生成多项式特征
    poly = PolynomialFeatures(degree=degree)
    time_series_poly = poly.fit_transform(time_series.reshape(-1, 1))

    # 创建线性回归模型
    model = LinearRegression()
    model.fit(time_series_poly, events)

    # 使用交叉验证来评估模型的表现
    scores = cross_val_score(model, time_series_poly, events, cv=5, scoring='neg_mean_squared_error')
    print(f"Degree {degree} - 交叉验证得分: {scores.mean()}")  # 打印每个degree的交叉验证得分

    return model, poly


# 测试不同的多项式阶数，选择效果最好的阶数
best_model = None
best_poly = None
best_degree = 1
best_score = float('inf')

for degree in range(1, 5):  # 尝试1到4阶的多项式
    model, poly = polynomial_regression(degree)
    # 计算交叉验证的平均得分（较小的得分代表较好的拟合）
    score = -cross_val_score(model, poly.transform(time_series.reshape(-1, 1)), events, cv=5,
                             scoring='neg_mean_squared_error').mean()
    if score < best_score:
        best_score = score
        best_model = model
        best_poly = poly
        best_degree = degree

print(f"最佳的多项式阶数为: {best_degree}")

# 预测2028年的事件数
prediction_2028_poly = best_model.predict(best_poly.transform([[8]]))  # 第8个时间点即2028年
print(f"预测2028年事件数：{prediction_2028_poly[0]}")

# 绘制原始数据与最佳多项式回归预测数据的对比
plt.plot(years, events, label='Original Data', marker='o')
plt.plot(years, best_model.predict(best_poly.transform(time_series.reshape(-1, 1))),
         label=f'Polynomial Regression (Degree {best_degree})', linestyle='dashed', marker='x')
plt.plot(2028, prediction_2028_poly[0], label=f'Polynomial Regression Prediction (2028)', marker='*', color='red')
plt.xlabel('Year')
plt.ylabel('Number of Events')
plt.legend()
plt.title('Polynomial Regression - Event Number Prediction')
plt.grid(True)
plt.show()
