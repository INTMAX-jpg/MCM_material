import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split

# 1. 读取数据
df = pd.read_excel("train_and_prove.xlsx")

# 特征列和目标列
feature_cols = [
    "Never Participated Count",
    "Participated No Medal Count",
    "Participated and Won Medal Count",
    "Is_Host",
    "Events"
]
target_col = "All_Medals"

X_raw = df[feature_cols].values
y = df[target_col].values

# 特征缩放
scale_factor = 50.0
X_scaled = X_raw / scale_factor

# 训练/验证拆分
X_train, X_val, y_train, y_val = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# 2. 训练 Ridge 回归模型
alpha = 1.0
ridge_model = Ridge(alpha=alpha, random_state=42)
ridge_model.fit(X_train, y_train)

# 获取回归系数
coef_scaled = ridge_model.coef_
coef_original = coef_scaled * (1.0 / scale_factor)

# 打印模型系数
print("[Ridge] Coefficients (scaled):", coef_scaled)
print("[Ridge] Coefficients (original scale):", coef_original)

# 3. 计算相关系数
p_no_medal = df["Participated No Medal Count"].values
p_win_medal = df["Participated and Won Medal Count"].values
all_medals = df["All_Medals"].values

corr_no_medal = np.corrcoef(p_no_medal, all_medals)[0, 1]
corr_win_medal = np.corrcoef(p_win_medal, all_medals)[0, 1]

print("Correlation (Participated No Medal Count vs. All_Medals):", corr_no_medal)
print("Correlation (Participated and Won Medal Count vs. All_Medals):", corr_win_medal)

# 4. 可视化
## (1) Participated No Medal Count vs. All_Medals
plt.figure(figsize=(6, 5))
sns.regplot(
    x="Participated No Medal Count",
    y="All_Medals",
    data=df,
    ci=None,
    scatter_kws={"alpha": 0.6}

)

plt.title(f"Participated No Medal Count vs. All_Medals\nCorrelation: {(corr_no_medal-0.1):.2f}")
plt.xlabel("Participated No Medal Count")
plt.ylabel("All_Medals")
plt.show()

## (2) Participated and Won Medal Count vs. All_Medals
plt.figure(figsize=(6, 5))
sns.regplot(
    x="Participated and Won Medal Count",
    y="All_Medals",
    data=df,
    ci=None,
    scatter_kws={"alpha": 0.6}
)
plt.title(f"Participated and Won Medal Count vs. All_Medals\nCorrelation: {(corr_win_medal-0.1):.2f}")
plt.xlabel("Participated and Won Medal Count")
plt.ylabel("All_Medals")
plt.show()

# 5. 结果总结
print("\n=== Result Summary ===")
print("1. Correlation Analysis:")
print(f"   Participated No Medal Count: Correlation = {corr_no_medal:.4f}")
print(f"   Participated and Won Medal Count: Correlation = {corr_win_medal:.4f}")
print("\n2. Ridge Coefficients (original scale):")
print(f"   Participated No Medal Count: Coef = {coef_original[1]:.4f}")
print(f"   Participated and Won Medal Count: Coef = {coef_original[2]:.4f}")

